#!/bin/bash

SOURCE="$(pwd)"
DEST="$SOURCE/backups"
mkdir -p "$DEST"
DATE=$(date +%Y%m%d_%H%M%S)
tar -czf "$DEST/backup_$DATE.tar.gz" "$SOURCE/monitor.sh" "$SOURCE/backup.sh"
echo "Backup completed successfully!"
echo "Backup saved in: $DEST"
